import type { Course, Note } from './model';
export declare function LectureSite({ course, base, teacherNotes }: {
    course: Course;
    base?: string;
    teacherNotes?: Record<string, Note>;
}): import("react").JSX.Element;
