import type { ReactNode } from 'react';
export declare function Modal({ title, onClose, children }: {
    title: string;
    onClose: () => void;
    children: ReactNode;
}): import("react").JSX.Element;
