import type { Visual } from './model';
export declare function Infographic({ visual: v, base }: {
    visual: Visual;
    base?: string;
}): import("react").JSX.Element;
